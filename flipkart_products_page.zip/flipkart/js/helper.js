class Helper {
	addClass(ele, classList) {
		ele.classList.add(classList);
	}

	removeClass(ele, classList) {
		ele.classList.remove(classList);
	}

}